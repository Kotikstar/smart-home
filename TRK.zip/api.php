<?php
require 'config.php';
require 'functions.php';

$resource = $_GET['resource'] ?? '';
$action = $_GET['action'] ?? '';
header('Content-Type: application/json');

// ========== FUEL ==========
if ($resource === 'fuel') {
    if ($action === 'update') {
        $delta = floatval($_GET['delta'] ?? 0);
        $conn->query("UPDATE fuel SET amount = amount + ($delta)");
        $fuel = $conn->query("SELECT id, amount FROM fuel LIMIT 1")->fetch_assoc();

        if ($delta > 0) {
            $conn->query("INSERT INTO logs (card_id, amount, type) VALUES (NULL, $delta, 'refill')");
            setSetting('low_fuel_alert_sent', '0');
            sendGotify("Пополнение топлива", "Добавлено $delta л. Новый остаток: {$fuel['amount']} л.");
        }

        if ($fuel['amount'] >= 50) {
            $conn->query("UPDATE fuel SET alert_flag = 0 WHERE id = {$fuel['id']}");
        }

        echo json_encode(["amount" => floatval($fuel['amount'])]);
        exit;
    }

    $fuel = $conn->query("SELECT amount FROM fuel LIMIT 1")->fetch_assoc();
    echo json_encode(["amount" => floatval($fuel['amount'])]);
    exit;
}

// ========== CARDS ==========
if ($resource === 'cards') {

    // Добавление карты
    if ($action === 'add') {
        $name = $conn->real_escape_string($_GET['name'] ?? '');
        $identifier = $conn->real_escape_string($_GET['identifier'] ?? '');
        $limit = floatval($_GET['limit'] ?? 0);
        $conn->query("INSERT INTO cards (name, identifier, fuel_limit) VALUES ('$name', '$identifier', $limit)");
        sendGotify("Добавлена карта", "Карта $name ($identifier) добавлена. Лимит: $limit л.");
        echo json_encode(["success" => true]);
        exit;
    }

    // Удаление карты
    if ($action === 'delete') {
        $id = intval($_GET['id'] ?? 0);
        if ($id <= 0) {
            echo json_encode(["error" => "Некорректный ID"]);
            exit;
        }

        $card = $conn->query("SELECT * FROM cards WHERE id = $id")->fetch_assoc();
        if ($card) {
            $conn->query("DELETE FROM cards WHERE id = $id");
            sendGotify("Удалена карта", "Карта {$card['name']} ({$card['identifier']}) удалена.");
            echo json_encode(["success" => true]);
        } else {
            echo json_encode(["error" => "Карта не найдена"]);
        }
        exit;
    }

    // Пополнение карты
    if ($action === 'refill') {
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        $amount = floatval($_GET['amount'] ?? 0);
        
        if ($id <= 0 || $amount === 0) {
            echo json_encode(["success" => false, "message" => "Некорректные данные."]);
            exit;
        }

        $card = $conn->query("SELECT id, fuel_limit, used FROM cards WHERE id = $id")->fetch_assoc();
        if (!$card) {
            echo json_encode(["success" => false, "message" => "Карта не найдена"]);
            exit;
        }

        $new_limit = $card['fuel_limit'] + $amount;
        if ($new_limit < $card['used']) {
            echo json_encode(["success" => false, "message" => "Нельзя установить лимит меньше уже использованного."]);
            exit;
        }

        $conn->query("UPDATE cards SET fuel_limit = $new_limit WHERE id = $id");
        $conn->query("INSERT INTO logs (card_id, amount, type) VALUES ($id, $amount, 'refill')");
        sendGotify("Корректировка лимита", "Карта ID {$id} пополнена на {$amount} л.");
        echo json_encode(["success" => true]);
        exit;
    }

    // Получение всех карт
    $cards = $conn->query("SELECT id, name, identifier, fuel_limit, used FROM cards");
    $result = [];
    while ($row = $cards->fetch_assoc()) {
        $row['used'] = floatval($row['used']);
        $row['fuel_limit'] = floatval($row['fuel_limit']);
        $result[] = $row;
    }
    echo json_encode($result);
    exit;
}

// ========== DISPENSE ==========
if ($resource === 'dispense' && $action === 'issue') {
    $identifier = $conn->real_escape_string($_GET['identifier'] ?? '');
    $amount = floatval($_GET['amount'] ?? 0);

    $s = $conn->query("SELECT * FROM service WHERE status = 'in_service' LIMIT 1")->fetch_assoc();

if ($s) {
    $trans2 = ($s['type'] == "coarse") ? "грубой очистки" : "тонкой очистки";
    echo json_encode([
        "success" => false,
        "message" => "Невозможно выдать топливо — фильтр {$trans2} обслуживается."
    ]);
    exit;
}


    $card = $conn->query("SELECT * FROM cards WHERE identifier='$identifier'")->fetch_assoc();
    if (!$card) {
        echo json_encode(["success" => false, "message" => "Карта не найдена."]);
        exit;
    }

    if ($card['fuel_limit'] > 0 && $card['used'] + $amount > $card['fuel_limit']) {
        echo json_encode(["success" => false, "message" => "Превышен лимит карты."]);
        exit;
    }

    $fuel = $conn->query("SELECT id, amount FROM fuel LIMIT 1")->fetch_assoc();
    if (!$fuel || $fuel['amount'] < $amount) {
        echo json_encode(["success" => false, "message" => "Недостаточно топлива."]);
        exit;
    }

    $conn->query("UPDATE fuel SET amount = amount - $amount WHERE id = {$fuel['id']}");
    $conn->query("UPDATE cards SET used = used + $amount WHERE id = {$card['id']}");
    $conn->query("INSERT INTO logs (card_id, amount, type) VALUES ({$card['id']}, $amount, 'dispense')");

    $newFuel = $fuel['amount'] - $amount;
    sendGotify("Выдача топлива", "Карта {$card['name']} ({$card['identifier']}) выдала {$amount} л. Остаток: {$newFuel} л.");

    if ($newFuel < 100 && getSetting('low_fuel_alert_sent') !== '1') {
        sendGotify("ВНИМАНИЕ", "Остаток топлива критический: {$newFuel} л.");
        setSetting('low_fuel_alert_sent', '1');
    }

    echo json_encode(["success" => true]);
    exit;
}

// ========== STATS ==========
if ($resource === 'stats') {
    $dispensed = $conn->query("SELECT SUM(amount) AS sum FROM logs WHERE type='dispense'")->fetch_assoc()['sum'] ?? 0;
    $refilled = $conn->query("SELECT SUM(amount) AS sum FROM logs WHERE type='refill'")->fetch_assoc()['sum'] ?? 0;
    $top = $conn->query("SELECT cards.name, cards.identifier, SUM(logs.amount) AS total
                         FROM logs JOIN cards ON logs.card_id = cards.id
                         WHERE logs.type='dispense'
                         GROUP BY logs.card_id
                         ORDER BY total DESC LIMIT 1")->fetch_assoc();
    echo json_encode([
        "dispensed" => floatval($dispensed),
        "refilled" => floatval($refilled),
        "top_card" => $top ? "{$top['name']} ({$top['identifier']}) — {$top['total']} л" : null
    ]);
    exit;
}

// ========== CHART ==========
if ($resource === 'chart_data') {
    $labels = [];
    $dispense = [];
    $refill = [];
    for ($i = 6; $i >= 0; $i--) {
        $day = date('Y-m-d', strtotime("-$i days"));
        $labels[] = date('d.m', strtotime($day));
        $q1 = $conn->query("SELECT SUM(amount) as sum FROM logs WHERE DATE(created_at) = '$day' AND type='dispense'")->fetch_assoc();
        $q2 = $conn->query("SELECT SUM(amount) as sum FROM logs WHERE DATE(created_at) = '$day' AND type='refill'")->fetch_assoc();
        $dispense[] = floatval($q1['sum'] ?? 0);
        $refill[] = floatval($q2['sum'] ?? 0);
    }
    echo json_encode(["labels" => $labels, "dispense" => $dispense, "refill" => $refill]);
    exit;
}

// ========== LOGS ==========
if ($resource === 'logs') {
    $logs = $conn->query("SELECT logs.*, cards.name AS card_name, cards.identifier
                          FROM logs LEFT JOIN cards ON logs.card_id = cards.id
                          ORDER BY logs.created_at DESC LIMIT 100");
    echo json_encode(iterator_to_array($logs));
    exit;
}

// ========== SERVICE CONTROL ==========
if ($resource === 'service') {
    $types = ['coarse', 'fine'];

    if ($action === 'start') {
        $type = $_GET['type'] ?? '';
        if (!in_array($type, $types)) {
            echo json_encode(["error" => "Неверный тип"]);
            exit;
        }
        $trans1;
        if ($type == "coarse") {
            $trans1 = "грубой очистки";
        } else {
            $trans1 = "тонкой очистки";
        }
        $conn->query("UPDATE service SET status='in_service' WHERE type='$type'");
        sendGotify("Обслуживание начато", "Фильтр $trans1 в обслуживании.");
        echo json_encode(["success" => true]);
        exit;
    }

    if ($action === 'end') {
        $type = $_GET['type'] ?? '';
        if (!in_array($type, $types)) {
            echo json_encode(["error" => "Неверный тип"]);
            exit;
        }
        $now = date('Y-m-d H:i:s');
        $conn->query("UPDATE service SET status='ok', last_serviced='$now' WHERE type='$type'");
		$trans;
        if ($type == "coarse") {
            $trans = "грубой очистки";
        } else {
            $trans = "тонкой очистки";
        }
        sendGotify("Обслуживание завершено", "Фильтр $trans обслужен.");
        echo json_encode(["success" => true]);
        exit;
    }

    if ($action === 'set_interval') {
        $type = $_GET['type'] ?? '';
        $liters = floatval($_GET['liters'] ?? 0);
        if (!in_array($type, $types)) {
            echo json_encode(["error" => "Неверный тип"]);
            exit;
        }
        $conn->query("UPDATE service SET interval_liters=$liters WHERE type='$type'");
        echo json_encode(["success" => true]);
        exit;
    }

    // ----- Показать статус (как раньше) -----
    $result = [];
    foreach ($types as $t) {
        $row = $conn->query("SELECT * FROM service WHERE type='$t'")->fetch_assoc();
        if (!$row) {
            echo json_encode(["error" => "нет записи $t"]);
            exit;
        }

        $since = $row['last_serviced'];
        $sum = $conn->query("SELECT SUM(amount) as sum FROM logs WHERE type='dispense' AND created_at >= '$since'")->fetch_assoc();
        $elapsed = floatval($sum['sum'] ?? 0);

        $result[$t] = [
            'status' => $row['status'] === 'in_service' ? 'in_service' : 'normal',
            'last_service' => $row['last_serviced'],
            'elapsed' => $elapsed,
            'interval' => floatval($row['interval_liters'])
        ];
    }

    echo json_encode($result);
    exit;
}



// ========== DIESEL PRICES ==========
if ($resource === 'diesel_prices') {
    $prices = $conn->query("SELECT date, price FROM diesel_prices ORDER BY date ASC");
    echo json_encode(iterator_to_array($prices));
    exit;
}


// ========== DEFAULT ==========
echo json_encode(["error" => "Invalid resource"]);
