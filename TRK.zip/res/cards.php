<?php include 'header.php'; ?>
<div class="max-w-4xl mx-auto px-4 py-6 text-white">
  <h2 class="text-2xl font-bold mb-4">Топливные карты</h2>

  <div class="grid grid-cols-1 md:grid-cols-4 gap-4 bg-gray-800 p-4 rounded-lg mb-4">
    <input type="text" id="cardName" placeholder="Имя" class="p-2 rounded bg-gray-700 border border-gray-600">
    <input type="text" id="cardIdentifier" placeholder="ID карты" class="p-2 rounded bg-gray-700 border border-gray-600">
    <input type="number" id="cardLimit" placeholder="Лимит (л)" class="p-2 rounded bg-gray-700 border border-gray-600">
    <button onclick="addCard()" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
      Добавить карту
    </button>
  </div>

  <div class="overflow-x-auto">
    <table class="min-w-full bg-gray-800 rounded-lg overflow-hidden text-sm">
      <thead class="bg-gray-700 text-white">
        <tr>
          <th class="py-2 px-4">ID</th>
          <th class="py-2 px-4">Имя</th>
          <th class="py-2 px-4">Идентификатор</th>
          <th class="py-2 px-4">Лимит</th>
          <th class="py-2 px-4">Действия</th>
        </tr>
      </thead>
      <tbody id="cardsTable" class="divide-y divide-gray-600"></tbody>
    </table>
  </div>
</div>

<script>
function loadCards() {
  fetch('/api.php?resource=cards')
    .then(res => res.json())
    .then(cards => {
      const table = document.getElementById('cardsTable');
      table.innerHTML = '';
      cards.forEach(card => {
        const row = `<tr>
          <td class="py-2 px-4">${card.id}</td>
          <td class="py-2 px-4">${card.name}</td>
          <td class="py-2 px-4">${card.identifier}</td>
          <td class="py-2 px-4">${card.fuel_limit}</td>
          <td class="py-2 px-4">
            <button onclick="deleteCard(${card.id})" class="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded">Удалить</button>
          </td>
        </tr>`;
        table.innerHTML += row;
      });
    });
}

function addCard() {
  const name = document.getElementById('cardName').value;
  const identifier = document.getElementById('cardIdentifier').value;
  const limit = document.getElementById('cardLimit').value;

  fetch(`/api.php?resource=cards&action=create&name=${name}&identifier=${identifier}&limit=${limit}`)
    .then(res => res.json())
    .then(resp => {
      if (resp.success) {
        alert("Карта добавлена");
        loadCards();
      } else {
        alert("Ошибка добавления карты");
      }
    });
}

function deleteCard(id) {
  if (!confirm("Удалить карту?")) return;

  fetch(`/api.php?resource=cards&action=delete&id=${id}`)
    .then(res => res.json())
    .then(resp => {
      if (resp.success) {
        alert("Удалено");
        loadCards();
      } else {
        alert("Ошибка при удалении: " + (resp.message || ''));
      }
    });
}

loadCards();
</script>
<?php include 'footer.php'; ?>
