<?php
require_once 'config.php';

// Создание базы, если не существует
$conn->query("CREATE DATABASE IF NOT EXISTS trk_system");
$conn->select_db("trk_system");

// Создание таблиц
$conn->query("CREATE TABLE IF NOT EXISTS fuel (
  id INT AUTO_INCREMENT PRIMARY KEY,
  amount FLOAT NOT NULL DEFAULT 0,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)");

$conn->query("CREATE TABLE IF NOT EXISTS cards (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  identifier VARCHAR(100) UNIQUE,
  fuel_limit FLOAT DEFAULT 0,
  used FLOAT DEFAULT 0
)");


$conn->query("CREATE TABLE IF NOT EXISTS logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  card_id INT,
  amount FLOAT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (card_id) REFERENCES cards(id)
)");

echo "✅ База данных и таблицы успешно созданы.";
?>
