<?php include 'header.php'; ?>
<div class="max-w-6xl mx-auto px-4 py-6">
  <h2 class="text-2xl font-bold text-white mb-6">Панель управления</h2>
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    <div class="bg-blue-600 text-white p-6 rounded-xl shadow">
      <h3 class="text-lg font-semibold">Остаток топлива</h3>
      <p class="text-3xl mt-2" id="fuelAmount">-- л</p>
    </div>
    <div class="bg-green-600 text-white p-6 rounded-xl shadow">
      <h3 class="text-lg font-semibold">Активных карт</h3>
      <p class="text-3xl mt-2" id="cardCount">--</p>
    </div>
    <div class="bg-yellow-600 text-white p-6 rounded-xl shadow">
      <h3 class="text-lg font-semibold">Всего выдано</h3>
      <p class="text-3xl mt-2" id="fuelDispensed">-- л</p>
    </div>
    <div class="bg-purple-600 text-white p-6 rounded-xl shadow">
      <h3 class="text-lg font-semibold">Всего пополнено</h3>
      <p class="text-3xl mt-2" id="fuelRefilled">-- л</p>
    </div>
    <div class="bg-indigo-600 text-white p-6 rounded-xl shadow md:col-span-2 lg:col-span-1">
      <h3 class="text-lg font-semibold">Самая активная карта</h3>
      <p class="text-xl mt-2" id="topCard">--</p>
    </div>
  </div>
</div>

<script>
fetch('/api.php?resource=fuel')
  .then(r => r.json())
  .then(d => {
    document.getElementById('fuelAmount').innerText = d.amount + " л";
  });

fetch('/api.php?resource=cards')
  .then(r => r.json())
  .then(d => {
    document.getElementById('cardCount').innerText = d.length;
  });

fetch('/api.php?resource=stats')
  .then(r => r.json())
  .then(d => {
    document.getElementById('fuelDispensed').innerText = d.dispensed + " л";
    document.getElementById('fuelRefilled').innerText = d.refilled + " л";
    document.getElementById('topCard').innerText = d.top_card || "Нет данных";
  });
</script>

<?php include 'footer.php'; ?>
