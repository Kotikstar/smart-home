<?php
require_once 'config.php';
require_once 'functions.php';

header('Content-Type: application/json');

$resource = $_GET['resource'] ?? null;
$action = $_GET['action'] ?? null;

switch ($resource) {
    case 'fuel':
        if ($action === 'update') {
            $delta = floatval($_GET['delta'] ?? 0);
            $res = $conn->query("SELECT id, amount FROM fuel LIMIT 1");
            if ($row = $res->fetch_assoc()) {
                $new_amount = $row['amount'] + $delta;
                $conn->query("UPDATE fuel SET amount = $new_amount WHERE id = " . $row['id']);
            } else {
                $new_amount = $delta;
                $conn->query("INSERT INTO fuel (amount) VALUES ($new_amount)");
            }
            $conn->query("INSERT INTO logs (card_id, amount, type) VALUES (NULL, $delta, 'refill')");
            sendGotify("Обновление топлива", "Добавлено {$delta} л. Остаток: {$new_amount} л.");
            echo json_encode(["success" => true, "amount" => $new_amount]);
        } else {
            $res = $conn->query("SELECT amount FROM fuel LIMIT 1");
            $row = $res->fetch_assoc();
            echo json_encode(["amount" => $row['amount'] ?? 0]);
        }
        break;

    case 'cards':
        if ($action === 'create') {
            $name = $conn->real_escape_string($_GET['name']);
            $identifier = $conn->real_escape_string($_GET['identifier']);
            $fuel_limit = floatval($_GET['limit']);
            $conn->query("INSERT INTO cards (name, identifier, fuel_limit) VALUES ('$name', '$identifier', $fuel_limit)");
            sendGotify("Новая карта", "Карта $name ($identifier) добавлена.");
            echo json_encode(["success" => true]);
        } elseif ($action === 'update') {
            $id = intval($_GET['id']);
            $name = $conn->real_escape_string($_GET['name']);
            $identifier = $conn->real_escape_string($_GET['identifier']);
            $fuel_limit = floatval($_GET['limit']);
            $conn->query("UPDATE cards SET name='$name', identifier='$identifier', fuel_limit=$fuel_limit WHERE id=$id");
            echo json_encode(["success" => true]);
        } elseif ($action === 'delete') {
            $id = intval($_GET['id']);
            $res = $conn->query("SELECT name, identifier FROM cards WHERE id=$id");
            $card = $res->fetch_assoc();
            $resDel = $conn->query("DELETE FROM cards WHERE id=$id");
    if ($resDel) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "message" => $conn->error]);
    }
    exit;
            sendGotify("Удаление карты", "Карта {$card['name']} ({$card['identifier']}) удалена.");
            echo json_encode(["success" => true]);
        } else {
            $result = $conn->query("SELECT * FROM cards");
            $cards = [];
            while ($row = $result->fetch_assoc()) {
                $cards[] = $row;
            }
            echo json_encode($cards);
        }
        break;

    case 'dispense':
        if ($action === 'issue') {
            $identifier = $conn->real_escape_string($_GET['identifier'] ?? '');
            $amount = floatval($_GET['amount'] ?? 0);

            $card = $conn->query("SELECT * FROM cards WHERE identifier='$identifier'")->fetch_assoc();
            if (!$card) {
                echo json_encode(["success" => false, "message" => "Карта не найдена."]);
                exit;
            }

            if ($card['fuel_limit'] > 0 && $card['used'] + $amount > $card['fuel_limit']) {
                echo json_encode(["success" => false, "message" => "Превышен лимит карты."]);
                exit;
            }

            $fuel = $conn->query("SELECT id, amount FROM fuel LIMIT 1")->fetch_assoc();
            if (!$fuel || $fuel['amount'] < $amount) {
                echo json_encode(["success" => false, "message" => "Недостаточно топлива."]);
                exit;
            }

            $conn->query("UPDATE fuel SET amount = amount - $amount WHERE id = {$fuel['id']}");
            $conn->query("UPDATE cards SET used = used + $amount WHERE id = {$card['id']}");
            $conn->query("INSERT INTO logs (card_id, amount, type) VALUES ({$card['id']}, $amount, 'dispense')");

            $newFuel = $fuel['amount'] - $amount;
            sendGotify("Выдача топлива", "Карта {$card['name']} ({$card['identifier']}) выдала {$amount} л. Остаток: {$newFuel} л.");
            echo json_encode(["success" => true]);
        }
        break;

    case 'logs':
        $query = "SELECT logs.created_at, logs.amount, logs.type, cards.name, cards.identifier
                  FROM logs
                  LEFT JOIN cards ON cards.id = logs.card_id
                  WHERE 1=1";

        if (!empty($_GET['identifier'])) {
            $id = $conn->real_escape_string($_GET['identifier']);
            $query .= " AND cards.identifier = '$id'";
        }

        if (!empty($_GET['from'])) {
            $from = $conn->real_escape_string($_GET['from']);
            $query .= " AND logs.created_at >= '$from 00:00:00'";
        }

        if (!empty($_GET['to'])) {
            $to = $conn->real_escape_string($_GET['to']);
            $query .= " AND logs.created_at <= '$to 23:59:59'";
        }

        $query .= " ORDER BY logs.created_at DESC";

        $res = $conn->query($query);
        $logs = [];
        while ($row = $res->fetch_assoc()) {
            $logs[] = $row;
        }
        echo json_encode($logs);
        break;

    default:
        echo json_encode(["error" => "Invalid resource"]);
}



// STATS: статистика для дашборда
if ($resource === 'stats') {
    // всего выдано
    $dispensed = $conn->query("SELECT SUM(amount) as total FROM logs WHERE type='dispense'")->fetch_assoc()['total'] ?? 0;

    // всего пополнено
    $refilled = $conn->query("SELECT SUM(amount) as total FROM logs WHERE type='refill'")->fetch_assoc()['total'] ?? 0;

    // топ карта
    $top = $conn->query("SELECT cards.name, cards.identifier, SUM(logs.amount) as total 
                         FROM logs 
                         JOIN cards ON cards.id = logs.card_id 
                         WHERE logs.type='dispense' 
                         GROUP BY card_id 
                         ORDER BY total DESC 
                         LIMIT 1")->fetch_assoc();

    echo json_encode([
        "dispensed" => round(floatval($dispensed), 2),
        "refilled" => round(floatval($refilled), 2),
        "top_card" => $top ? "{$top['name']} ({$top['identifier']}) — {$top['total']} л" : null
    ]);
    exit;
}
?>